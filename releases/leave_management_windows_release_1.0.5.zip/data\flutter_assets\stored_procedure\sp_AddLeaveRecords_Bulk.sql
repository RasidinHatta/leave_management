SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'[dbo].[sp_AddLeaveRecords_Bulk]', N'P') IS NOT NULL
    DROP PROCEDURE [dbo].[sp_AddLeaveRecords_Bulk]
GO

DROP TYPE IF EXISTS [dbo].[LeaveImportList]
GO

CREATE TYPE [dbo].[LeaveImportList] AS TABLE
(
    [EMP_CODE] [varchar](50) NULL,
    [LV_DATE] [date] NULL,
    [LV_CODE] [varchar](50) NULL,
    [REMARK] [varchar](255) NULL
)
GO

CREATE PROCEDURE [dbo].[sp_AddLeaveRecords_Bulk]
(
    @List dbo.LeaveImportList READONLY
)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRAN;

        DECLARE @RequestedCount int = (SELECT COUNT(*) FROM @List);

        IF @RequestedCount = 0
        BEGIN
            THROW 50008, 'No leave records were provided for import.', 1;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM @List
            WHERE EMP_CODE IS NULL OR LTRIM(RTRIM(EMP_CODE)) = ''
               OR LV_DATE IS NULL
               OR LV_CODE IS NULL OR LTRIM(RTRIM(LV_CODE)) = ''
        )
        BEGIN
            THROW 50009, 'Employee code, leave date, and leave code are required.', 1;
        END;

        ------------------------------------------------------------
        -- 1. Validate leave code
        ------------------------------------------------------------
        IF EXISTS
        (
            SELECT 1
            FROM @List L
            LEFT JOIN dbo.[LV_TYPE] T
                ON T.LV_CODE = L.LV_CODE
               AND (T.LV_EVENT_CODE = 'LEAVE' OR T.LV_CODE IN ('PH', 'OFF', 'RL', 'REST'))
            WHERE T.LV_CODE IS NULL
        )
        BEGIN
            THROW 50001, 'Invalid leave code found. Please check LV_TYPE setup.', 1;
        END;

        ------------------------------------------------------------
        -- 2. Prevent duplicate same leave code inside import list
        --    Example: same staff same date FHA + FHA not allowed
        ------------------------------------------------------------
        IF EXISTS
        (
            SELECT 1
            FROM @List L
            GROUP BY
                L.EMP_CODE,
                L.LV_DATE,
                L.LV_CODE
            HAVING COUNT(*) > 1
        )
        BEGIN
            THROW 50004, 'Import list contains duplicate leave code for the same employee and date.', 1;
        END;

        ------------------------------------------------------------
        -- 3. Prevent duplicate same leave code in LV_RECORDS
        --    Example: FHA already exists, cannot insert FHA again
        ------------------------------------------------------------
        IF EXISTS
        (
            SELECT 1
            FROM @List L
            INNER JOIN dbo.[LV_RECORDS] R
                ON R.EMP_CODE = L.EMP_CODE
               AND CAST(R.LV_DATE AS date) = L.LV_DATE
               AND R.LV_CODE = L.LV_CODE
        )
        BEGIN
            THROW 50003, 'Same leave code already exists for this employee on the same date.', 1;
        END;

        ------------------------------------------------------------
        -- 4. Prevent total leave day on same employee/date exceed 1 day
        --    Allow half day + half day only when total <= 1.00
        ------------------------------------------------------------
        IF EXISTS
        (
            SELECT 1
            FROM
            (
                SELECT
                    L.EMP_CODE,
                    L.LV_DATE,
                    SUM(ISNULL(T.DAY_, 1)) AS NEW_DAY
                FROM @List L
                INNER JOIN dbo.[LV_TYPE] T
                    ON T.LV_CODE = L.LV_CODE
                   AND T.LV_EVENT_CODE = 'LEAVE'
                GROUP BY
                    L.EMP_CODE,
                    L.LV_DATE
            ) N
            LEFT JOIN
            (
                SELECT
                    R.EMP_CODE,
                    R.LV_DATE,
                    SUM(ISNULL(R.DAY_, 0)) AS EXISTING_DAY
                FROM dbo.[LV_RECORDS] R
                WHERE R.LV_EVENT_CODE = 'LEAVE'
                GROUP BY
                    R.EMP_CODE,
                    R.LV_DATE
            ) E
                ON E.EMP_CODE = N.EMP_CODE
               AND E.LV_DATE = N.LV_DATE
            WHERE ISNULL(E.EXISTING_DAY, 0) + ISNULL(N.NEW_DAY, 0) > 1.00
        )
        BEGIN
            THROW 50005, 'Total leave day for the same employee and date cannot exceed 1 day.', 1;
        END;

        ------------------------------------------------------------
        -- 4A. Prevent duplicate half-day portion inside import list
        --     Example:
        --     FHA + FML = not allowed because both are First Half
        --     SHA + SML = not allowed because both are Second Half
        ------------------------------------------------------------
        IF EXISTS
        (
            SELECT 1
            FROM
            (
                SELECT
                    L.EMP_CODE,
                    L.LV_DATE,
                    T.LV_DAY_PORTION_CODE
                FROM @List L
                INNER JOIN dbo.[LV_TYPE] T
                    ON T.LV_CODE = L.LV_CODE
                   AND T.LV_EVENT_CODE = 'LEAVE'
                WHERE ISNULL(T.DAY_, 1) < 1
                  AND ISNULL(T.LV_DAY_PORTION_CODE, '') <> ''
            ) X
            GROUP BY
                X.EMP_CODE,
                X.LV_DATE,
                X.LV_DAY_PORTION_CODE
            HAVING COUNT(*) > 1
        )
        BEGIN
            THROW 50006, 'Import list contains duplicate half-day portion for the same employee and date.', 1;
        END;

        ------------------------------------------------------------
        -- 4B. Prevent new leave from using same half-day portion
        --     as existing LV_RECORDS
        --     Example:
        --     Existing FHA, then insert FML = not allowed
        --     Existing FHA, then insert SML = allowed
        ------------------------------------------------------------
        IF EXISTS
        (
            SELECT 1
            FROM @List L
            INNER JOIN dbo.[LV_TYPE] T
                ON T.LV_CODE = L.LV_CODE
               AND T.LV_EVENT_CODE = 'LEAVE'
            INNER JOIN dbo.[LV_RECORDS] R
                ON R.EMP_CODE = L.EMP_CODE
               AND R.LV_DATE = L.LV_DATE
               AND R.LV_EVENT_CODE = 'LEAVE'
            WHERE ISNULL(T.DAY_, 1) < 1
              AND ISNULL(R.DAY_, 1) < 1
              AND ISNULL(T.LV_DAY_PORTION_CODE, '') <> ''
              AND ISNULL(R.LV_DAY_PORTION_CODE, '') = ISNULL(T.LV_DAY_PORTION_CODE, '')
        )
        BEGIN
            THROW 50007, 'Same half-day portion already exists for this employee on the same date.', 1;
        END;

        ------------------------------------------------------------
        -- 5. Store inserted leave records
        -- LV_RECORDS is allowed to receive valid leave before LV_SUMMARY is
        -- initialized. Recalculation below updates whichever summary months
        -- exist and can be run again after the remaining months are created.
        ------------------------------------------------------------
        DECLARE @InsertedLeave TABLE
        (
            EMP_CODE varchar(50),
            LV_DATE  date,
            LV_CODE  varchar(50),
            DAY_     decimal(18,2),
            LV_EVENT_CODE varchar(50)
        );

        ------------------------------------------------------------
        -- 7. Insert into LV_RECORDS
        --    Important:
        --    LV_RECORDS keeps original LV_CODE.
        --    Example: FHA remains FHA, SML remains SML.
        ------------------------------------------------------------
        INSERT INTO dbo.[LV_RECORDS]
        (
            EMP_CODE,
            LV_DATE,
            LV_CODE,
            DAY_,
            LV_APP_DATE,
            REMARK,
            LV_EVENT_CODE,
            LV_DAY_PORTION_CODE,
            SYSTEM_CODE
        )
        OUTPUT
            inserted.EMP_CODE,
            inserted.LV_DATE,
            inserted.LV_CODE,
            inserted.DAY_,
            inserted.LV_EVENT_CODE
        INTO @InsertedLeave
        SELECT
            L.EMP_CODE,
            L.LV_DATE,
            L.LV_CODE,
            ISNULL(T.DAY_, 1),
            GETDATE(),
            L.REMARK,
            T.LV_EVENT_CODE,
            T.LV_DAY_PORTION_CODE,
            'ELEAVE'
        FROM @List L
        INNER JOIN dbo.[LV_TYPE] T
            ON T.LV_CODE = L.LV_CODE
           AND (T.LV_EVENT_CODE = 'LEAVE' OR T.LV_CODE IN ('PH', 'OFF', 'RL', 'REST'));

        DECLARE @InsertedCount int = (SELECT COUNT(*) FROM @InsertedLeave);

        IF @InsertedCount <> @RequestedCount
        BEGIN
            THROW 50010, 'Leave records were not inserted. Please check employee codes and leave type setup.', 1;
        END;

        ------------------------------------------------------------
        -- 8. Recalculate LV_SUMMARY from LV_RECORDS
        --    LV_RECORDS is the source of truth.
        --    LV_RECORDS uses actual code: FHA / SHA / FML / SML
        --    LV_SUMMARY uses mapped group: AL / ML
        --    Use LV_DATE month, not LV_APP_DATE month.
        --    Annual columns are recalculated for all 12 months.
        --    YTD columns are recalculated by each summary month.
        ------------------------------------------------------------
        ;WITH AffectedLeaveGroups AS
        (
            SELECT
                EMP_CODE,
                YEAR(LV_DATE) AS YEAR_,
                CASE 
                    WHEN LV_CODE IN ('AL', 'FHA', 'SHA') THEN 'AL'
                    WHEN LV_CODE IN ('FCP', 'SCP') THEN 'CPL'
                    WHEN LV_CODE IN ('FEL', 'SEL') THEN 'EL'
                    WHEN LV_CODE IN ('FML', 'SML') THEN 'ML'
                    WHEN LV_CODE IN ('FSD', 'SSD') THEN 'STD'
                    WHEN LV_CODE IN ('FUL', 'SUL') THEN 'UL'
                    ELSE LV_CODE
                END AS LV_GROUP_CODE
            FROM @InsertedLeave
            WHERE LV_EVENT_CODE = 'LEAVE'
            GROUP BY
                EMP_CODE,
                YEAR(LV_DATE),
                CASE 
                    WHEN LV_CODE IN ('AL', 'FHA', 'SHA') THEN 'AL'
                    WHEN LV_CODE IN ('FCP', 'SCP') THEN 'CPL'
                    WHEN LV_CODE IN ('FEL', 'SEL') THEN 'EL'
                    WHEN LV_CODE IN ('FML', 'SML') THEN 'ML'
                    WHEN LV_CODE IN ('FSD', 'SSD') THEN 'STD'
                    WHEN LV_CODE IN ('FUL', 'SUL') THEN 'UL'
                    ELSE LV_CODE
                END
        ),
        LeaveRecordsMapped AS
        (
            SELECT
                R.EMP_CODE,
                YEAR(R.LV_DATE) AS YEAR_,
                MONTH(R.LV_DATE) AS MONTH_,
                CASE 
                    WHEN R.LV_CODE IN ('AL', 'FHA', 'SHA') THEN 'AL'
                    WHEN R.LV_CODE IN ('FCP', 'SCP') THEN 'CPL'
                    WHEN R.LV_CODE IN ('FEL', 'SEL') THEN 'EL'
                    WHEN R.LV_CODE IN ('FML', 'SML') THEN 'ML'
                    WHEN R.LV_CODE IN ('FSD', 'SSD') THEN 'STD'
                    WHEN R.LV_CODE IN ('FUL', 'SUL') THEN 'UL'
                    ELSE R.LV_CODE
                END AS LV_GROUP_CODE,
                ISNULL(R.DAY_, 0) AS TAKEN_DAY
            FROM dbo.[LV_RECORDS] R
            INNER JOIN AffectedLeaveGroups A
                ON A.EMP_CODE = R.EMP_CODE
               AND A.YEAR_ = YEAR(R.LV_DATE)
               AND A.LV_GROUP_CODE =
                    CASE 
                        WHEN R.LV_CODE IN ('AL', 'FHA', 'SHA') THEN 'AL'
                        WHEN R.LV_CODE IN ('FCP', 'SCP') THEN 'CPL'
                        WHEN R.LV_CODE IN ('FEL', 'SEL') THEN 'EL'
                        WHEN R.LV_CODE IN ('FML', 'SML') THEN 'ML'
                        WHEN R.LV_CODE IN ('FSD', 'SSD') THEN 'STD'
                        WHEN R.LV_CODE IN ('FUL', 'SUL') THEN 'UL'
                        ELSE R.LV_CODE
                    END
            WHERE R.LV_EVENT_CODE = 'LEAVE'
        ),
        AnnualLeaveTaken AS
        (
            SELECT
                EMP_CODE,
                YEAR_,
                LV_GROUP_CODE,
                SUM(TAKEN_DAY) AS TAKEN_DAY
            FROM LeaveRecordsMapped
            GROUP BY
                EMP_CODE,
                YEAR_,
                LV_GROUP_CODE
        ),
        BringForwardFromRecords AS
        (
            SELECT
                R.EMP_CODE,
                YEAR(R.LV_DATE) AS YEAR_,
                SUM(ISNULL(R.DAY_, 0)) AS BF_DAY
            FROM dbo.[LV_RECORDS] R
            INNER JOIN AffectedLeaveGroups A
                ON A.EMP_CODE = R.EMP_CODE
               AND A.YEAR_ = YEAR(R.LV_DATE)
               AND A.LV_GROUP_CODE = 'AL'
            WHERE R.LV_CODE = 'BF(AL)'
              AND R.LV_EVENT_CODE = 'BRINGFORWARD'
            GROUP BY
                R.EMP_CODE,
                YEAR(R.LV_DATE)
        ),
        SummaryUpdate AS
        (
            SELECT
                S.EMP_CODE,
                S.YEAR_,
                S.MONTH_,
                S.LV_GROUP_CODE,
                ISNULL(A.TAKEN_DAY, 0) AS TAKEN_DAY,
                CASE
                    WHEN S.LV_GROUP_CODE = 'AL' THEN ISNULL(BF.BF_DAY, 0)
                    ELSE ISNULL(S.BF, 0)
                END AS BF_DAY,
                CASE
                    WHEN S.LV_GROUP_CODE = 'AL' THEN
                        ISNULL(S.YTD, 0)
                      - ISNULL(S.YTD_BF, 0)
                      + ISNULL(BF.BF_DAY, 0)
                    ELSE ISNULL(S.YTD, 0)
                END AS YTD_DAY,
                ISNULL(SUM(
                    CASE
                        WHEN L.MONTH_ <= S.MONTH_ THEN L.TAKEN_DAY
                        ELSE 0
                    END
                ), 0) AS YTD_TAKEN_DAY
            FROM dbo.[LV_SUMMARY] S
            INNER JOIN AffectedLeaveGroups G
                ON S.EMP_CODE = G.EMP_CODE
               AND S.YEAR_ = G.YEAR_
               AND S.LV_GROUP_CODE = G.LV_GROUP_CODE
            LEFT JOIN AnnualLeaveTaken A
                ON S.EMP_CODE = A.EMP_CODE
               AND S.YEAR_ = A.YEAR_
               AND S.LV_GROUP_CODE = A.LV_GROUP_CODE
            LEFT JOIN BringForwardFromRecords BF
                ON S.EMP_CODE = BF.EMP_CODE
               AND S.YEAR_ = BF.YEAR_
            LEFT JOIN LeaveRecordsMapped L
                ON S.EMP_CODE = L.EMP_CODE
               AND S.YEAR_ = L.YEAR_
               AND S.LV_GROUP_CODE = L.LV_GROUP_CODE
            WHERE S.MONTH_ BETWEEN 1 AND 12
            GROUP BY
                S.EMP_CODE,
                S.YEAR_,
                S.MONTH_,
                S.LV_GROUP_CODE,
                A.TAKEN_DAY,
                BF.BF_DAY,
                S.BF,
                S.YTD,
                S.YTD_BF
        )
        UPDATE S
        SET
            S.BF = CASE
                WHEN S.LV_GROUP_CODE = 'AL' THEN U.BF_DAY
                ELSE S.BF
            END,

            S.TAKEN = U.TAKEN_DAY,

            S.YTD = CASE
                WHEN S.LV_GROUP_CODE = 'AL' THEN U.YTD_DAY
                ELSE S.YTD
            END,

            S.YTD_BF = CASE
                WHEN S.LV_GROUP_CODE = 'AL' THEN U.BF_DAY
                ELSE S.YTD_BF
            END,

            S.YTD_TAKEN = U.YTD_TAKEN_DAY,

            S.BAL =
                ISNULL(S.ENT, 0)
              + U.BF_DAY
              + ISNULL(S.CR, 0)
              - ISNULL(S.BURN, 0)
              - U.TAKEN_DAY
              - ISNULL(S.ENCASH, 0)
              - ISNULL(S.FORFEIT, 0),

            S.YTD_BAL =
                U.YTD_DAY
              - ISNULL(S.YTD_BURN, 0)
              - U.YTD_TAKEN_DAY
              - ISNULL(S.YTD_ENCASH, 0)
              - ISNULL(S.YTD_FORFEIT, 0),

            S.BAL_YEAR =
                ISNULL(S.ENT, 0)
              + U.BF_DAY
              + ISNULL(S.CR, 0)
              - ISNULL(S.BURN, 0)
              - U.TAKEN_DAY
              - ISNULL(S.ENCASH, 0)
              - ISNULL(S.FORFEIT, 0)
        FROM dbo.[LV_SUMMARY] S
        INNER JOIN SummaryUpdate U
            ON S.EMP_CODE = U.EMP_CODE
           AND S.YEAR_ = U.YEAR_
           AND S.MONTH_ = U.MONTH_
           AND S.LV_GROUP_CODE = U.LV_GROUP_CODE;

        DECLARE @UpdatedSummaryRows int = @@ROWCOUNT;

        COMMIT;

        SELECT
            @InsertedCount AS insertedCount,
            @UpdatedSummaryRows AS updatedSummaryRows;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        THROW;
    END CATCH
END;
GO
